package practice_9;

public class Nurses {
	private int nur_seq;
	private int nur_id;
	private String major_job;
	private String nur_name;
	private String nur_gen;
	private String nur_phone;
	private String nur_email;
	private String nur_position;
	
	public Nurses(int nur_seq) {
		this.nur_seq = nur_seq;
	}

	public int getNur_seq() {
		return nur_seq;
	}

	public void setNur_seq(int nur_seq) {
		this.nur_seq = nur_seq;
	}

	public int getNur_id() {
		return nur_id;
	}

	public void setNur_id(int nur_id) {
		this.nur_id = nur_id;
	}

	public String getMajor_job() {
		return major_job;
	}

	public void setMajor_job(String major_job) {
		this.major_job = major_job;
	}

	public String getNur_name() {
		return nur_name;
	}

	public void setNur_name(String nur_name) {
		this.nur_name = nur_name;
	}

	public String getNur_gen() {
		return nur_gen;
	}

	public void setNur_gen(String nur_gen) {
		this.nur_gen = nur_gen;
	}

	public String getNur_phone() {
		return nur_phone;
	}

	public void setNur_phone(String nur_phone) {
		this.nur_phone = nur_phone;
	}

	public String getNur_email() {
		return nur_email;
	}

	public void setNur_email(String nur_email) {
		this.nur_email = nur_email;
	}

	public String getNur_position() {
		return nur_position;
	}

	public void setNur_position(String nur_position) {
		this.nur_position = nur_position;
	}
	
	
}
